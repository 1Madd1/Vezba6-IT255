export class Osoba {
    ime : string;
    prezime : string;
   titula: string;
    kvalifikacija: string;
}